# Smart Classroom
Project by Trang Thanh Vu, Savita Gopalakrishna Pillay, Christian Bauer, Alexander Frey and Diyar Takak


### Source of dataset